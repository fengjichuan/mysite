Welcome to jQuery HighchartTable plugin :)

This plugin provides you a simple way to convert HTML data tables to Highcharts graphs.

You will find more information here : http://pmsipilot.github.com/jquery-highchartTable-plugin
