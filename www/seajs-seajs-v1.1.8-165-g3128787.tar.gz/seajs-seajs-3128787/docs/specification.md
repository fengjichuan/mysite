
The CMD (Common Module Definition) in SeaJS is inspired by the following specifications:

* http://wiki.commonjs.org/wiki/Modules/1.1.1
* https://github.com/joyent/node/blob/master/doc/api/modules.markdown
* https://github.com/kriskowal/uncommonjs/blob/master/modules/specification.md
* http://wiki.commonjs.org/wiki/Modules/Wrappings
* http://www.page.ca/~wes/CommonJS/
* https://github.com/amdjs/amdjs-api/wiki/AMD

Thanks for all the awesome work above.
