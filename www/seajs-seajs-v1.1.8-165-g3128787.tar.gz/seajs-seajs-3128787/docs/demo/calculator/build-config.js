module.exports = {
  "loader_config": "./init.js",

  "base_path": "../../../../seajs/spm/modules/",
  "app_url": "http://seajs.org/docs/demo/calculator/online"
};
