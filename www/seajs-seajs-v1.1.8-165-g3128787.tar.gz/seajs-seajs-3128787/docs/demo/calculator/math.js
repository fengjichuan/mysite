
define(function(require, exports) {

  exports.add = function(n, m) {
    return n + m;
  };

  exports.subtract = function(n, m) {
    return n - m;
  };

  exports.multiple = function(n, m) {
    return n * m;
  };

  exports.divide = function(n, m) {
    return n / m;
  };

});
