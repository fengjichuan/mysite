<?php
  header('Content-type: text/css; charset=utf-8');
  sleep(2);
?>

#blue { color: blue }
