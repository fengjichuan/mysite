define( { name: 'b' } )
