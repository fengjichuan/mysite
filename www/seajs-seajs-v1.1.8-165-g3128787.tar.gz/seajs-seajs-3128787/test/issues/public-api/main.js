define(function(require) {

  require('./a')

})
