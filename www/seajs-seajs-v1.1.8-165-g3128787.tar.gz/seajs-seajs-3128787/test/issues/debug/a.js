define(function(require, exports, module) {

  exports.uri = module.uri;

});
