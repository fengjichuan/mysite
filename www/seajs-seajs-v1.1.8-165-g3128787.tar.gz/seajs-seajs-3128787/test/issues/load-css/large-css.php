<?php
header('Content-type: text/css');
sleep(120);
?>
body {
  background: #fff;
}
