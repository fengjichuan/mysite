
seajs.config({
      map: [
        ['a.js', 'a-debug.js'],
        ['b.js', 'sub/b.js'],
        ['c.js', 'sub/c.js']
      ]
    });
