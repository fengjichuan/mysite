
console.log('loaded');

define(function(require, exports) {

  exports.click = function() {
    console.log('clicked');
  };

});
