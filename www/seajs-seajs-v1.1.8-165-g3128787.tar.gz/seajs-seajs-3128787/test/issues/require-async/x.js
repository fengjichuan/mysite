
console.log('x.js is loaded');
