define('./d', { name: 'd' })
define('./e', { name: 'e' })
