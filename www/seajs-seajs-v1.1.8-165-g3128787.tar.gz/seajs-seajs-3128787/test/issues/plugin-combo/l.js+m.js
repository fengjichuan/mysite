define('./l', { name: 'l' })
define('./m', { name: 'm' })
