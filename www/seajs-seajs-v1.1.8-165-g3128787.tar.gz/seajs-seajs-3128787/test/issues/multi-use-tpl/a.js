define(function(require, exports) {

  exports.tpl = require('./default.tpl')

})
