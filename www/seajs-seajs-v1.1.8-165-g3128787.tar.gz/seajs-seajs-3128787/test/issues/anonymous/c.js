define({ name: 'c' });
define(pageBase + 'c2.js', { name: 'c2' });