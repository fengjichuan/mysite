define(function(require, exports, module) {

  function Person() {}

  module.exports = Person;

});
