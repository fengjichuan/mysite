define('http://example.com/libs/b', { name: 'b' })
