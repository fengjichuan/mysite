define('#a-debug', { name: 'a-debug' })
