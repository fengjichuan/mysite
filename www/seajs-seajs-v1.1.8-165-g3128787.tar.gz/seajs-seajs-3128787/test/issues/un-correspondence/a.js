define('#a', { name: 'a' })
