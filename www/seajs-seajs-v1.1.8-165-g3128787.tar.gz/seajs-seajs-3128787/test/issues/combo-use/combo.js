define('a', 'a.js');
define('b', 'b.js');
