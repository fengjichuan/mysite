define(function(require){
	
	var c = require('c');

	return {
		init : function(){
			log('b');
      c.init();
		}
	};

});