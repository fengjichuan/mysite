define(function(require){
	
	var a = require('a');

	return {
		init : function(){
			log('c');
		}
	};

});