define(function(require) {

  var test = require('../../test')

  test.assert(true, 'main.js is loaded')

})
