if (this['DEBUG']) {
  print('g.js is executed')
  out.push('G')
}
else {
  print('g.js is cached')
}
