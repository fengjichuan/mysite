if (this['DEBUG']) {
  print('d.js is executed')
  out.push('D')
}
else {
  print('d.js is cached')
}
