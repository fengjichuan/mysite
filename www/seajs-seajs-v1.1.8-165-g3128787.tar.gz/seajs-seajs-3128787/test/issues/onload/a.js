if (this['DEBUG']) {
  print('a.js is executed')
  out.push('A')
}
else {
  print('a.js is cached')
}
