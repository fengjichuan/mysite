if (this['DEBUG']) {
  print('b.js is executed')
  out.push('B')
}
else {
  print('b.js is cached')
}
