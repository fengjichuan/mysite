if (this['DEBUG']) {
  print('h.js is executed')
  out.push('H')
}
else {
  print('h.js is cached')
}
