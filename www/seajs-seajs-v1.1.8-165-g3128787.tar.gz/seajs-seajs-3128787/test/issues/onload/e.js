if (this['DEBUG']) {
  print('e.js is executed')
  out.push('E')
}
else {
  print('e.js is cached')
}
