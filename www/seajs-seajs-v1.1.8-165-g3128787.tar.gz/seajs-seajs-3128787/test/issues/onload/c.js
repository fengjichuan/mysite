if (this['DEBUG']) {
  print('c.js is executed')
  out.push('C')
}
else {
  print('c.js is cached')
}
