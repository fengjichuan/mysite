if (this['DEBUG']) {
  print('i.js is executed')
  out.push('I')
}
else {
  print('i.js is cached')
}
