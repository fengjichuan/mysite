define('./b', function(require, exports) {

  exports.$ = require('$')

})
