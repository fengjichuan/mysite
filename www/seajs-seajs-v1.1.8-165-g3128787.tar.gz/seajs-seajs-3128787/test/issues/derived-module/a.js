define('./a', function(require, exports) {

  exports.$ = require('$')

})
