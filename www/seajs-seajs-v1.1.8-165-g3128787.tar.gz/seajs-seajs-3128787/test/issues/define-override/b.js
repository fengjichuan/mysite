define({ name: 'b' });
define('a', { name: 'a' });
