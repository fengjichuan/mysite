define(function(require, exports) {

  exports.name = 'd';

});
