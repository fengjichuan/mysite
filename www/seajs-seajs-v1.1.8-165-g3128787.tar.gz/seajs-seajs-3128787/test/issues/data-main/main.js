define(function(require) {
  var test = require('../../test');

  test.assert(true, 'relative data-main is ok');
  test.done();
});
