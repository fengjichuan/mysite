
Array.prototype.map = Array.prototype.map || function() {};
