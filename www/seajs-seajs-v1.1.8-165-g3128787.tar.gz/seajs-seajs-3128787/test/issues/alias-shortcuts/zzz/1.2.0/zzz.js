define({ name: 'zzz' })
