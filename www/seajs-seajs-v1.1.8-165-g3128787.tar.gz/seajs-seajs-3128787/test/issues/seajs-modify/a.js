define(function(require, exports) {

  exports.name = 'wrong'

})
