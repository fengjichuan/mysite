define({ name: 'a/a' });
