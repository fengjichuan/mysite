define('xxlib', function(require, exports) {
  exports.name = 'xxlib';
});
