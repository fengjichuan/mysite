define(function(require, exports) {

  exports.b = 'b';

});
