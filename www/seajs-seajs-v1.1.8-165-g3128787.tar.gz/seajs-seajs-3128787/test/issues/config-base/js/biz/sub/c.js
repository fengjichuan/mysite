define(function(require, exports) {

  exports.c = 'c';

});
