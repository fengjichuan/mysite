define(function(require, exports) {

  exports.a = 'a';

});
