define(function(require) {

  var test = require('../../test');

  test.assert(true, 'simplest case');
  test.done();

});
