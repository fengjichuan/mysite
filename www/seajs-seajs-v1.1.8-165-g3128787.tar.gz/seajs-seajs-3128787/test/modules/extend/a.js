define(function(require, exports, module) {

  exports.filename = module._filename();

});
