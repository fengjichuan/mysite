define(function(require, exports) {

  exports.foo = function () {
    return this;
  };

  exports.set = function (x) {
    this.x = x;
  };

  exports.get = function () {
    return this.x;
  };

  exports.getClosed = function () {
    return exports.x;
  };

});
