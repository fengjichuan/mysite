define(function (require, exports) {

  exports.foo = 1;

});
