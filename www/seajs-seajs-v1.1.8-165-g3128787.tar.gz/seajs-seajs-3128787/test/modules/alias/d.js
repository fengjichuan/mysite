define(function(require, exports) {

  exports.foo = 'd';

});
