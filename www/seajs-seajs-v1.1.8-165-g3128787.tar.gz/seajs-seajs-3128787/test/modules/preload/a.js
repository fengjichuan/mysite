define(function() {
  this.A = 'a';
});
