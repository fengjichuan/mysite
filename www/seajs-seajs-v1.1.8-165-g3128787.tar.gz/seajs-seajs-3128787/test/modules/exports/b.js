define(function(require, exports, module) {

  module.exports = { foo : 'b' };

});
