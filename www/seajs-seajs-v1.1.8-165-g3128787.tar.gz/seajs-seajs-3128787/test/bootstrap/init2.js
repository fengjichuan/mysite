define(function(require) {

  require('./hello2').sayHello();

});
