A Module Loader for the Web
===

SeaJS is a module loader for the web. It is designed to change the way that you
organize JavaScript. With SeaJS, it is pleasure to build cool web applications.

The official site: <http://seajs.org/>


## Questions?

If you have any questions, please feel free to ask through [New Issue](https://github.com/seajs/seajs/issues/new).


## License

SeaJS is available under the terms of the [MIT License](http://seajs.org/LICENSE.md).
