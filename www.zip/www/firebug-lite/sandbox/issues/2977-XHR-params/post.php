<?php
echo $_POST['name']; 
?>